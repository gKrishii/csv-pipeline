import os
import csv
import boto3
import io

s3_client = boto3.client('s3')
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    """
    Triggered by S3 when a .csv file is uploaded to the input bucket.
    """
    sns_topic_arn = os.environ['SNS_TOPIC_ARN']
    output_bucket = os.environ['OUTPUT_BUCKET']

    try:
        # 1. Parse event
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # 2. Download the CSV file content
        response = s3_client.get_object(Bucket=bucket, Key=key)
        csv_content = response['Body'].read().decode('utf-8')

        # 3. Transform the CSV data
        transformed_data = transform_csv(csv_content)

        # 4. Save transformed data to output bucket
        output_key = "transformed_" + key
        s3_client.put_object(
            Bucket=output_bucket,
            Key=output_key,
            Body=transformed_data.encode('utf-8')
        )

        # 5. Log success
        print(f"SUCCESS: {key} processed and saved to {output_bucket}/{output_key}")

    except Exception as e:
        error_message = f"FAILED to process {key} from bucket {bucket}. Error: {str(e)}"
        print(error_message)

        # 6. Notify via SNS
        sns_client.publish(
            TopicArn=sns_topic_arn,
            Subject="CSV Processing Failure",
            Message=error_message
        )

        # Re-raise so the Lambda logs an ERROR
        raise e

def transform_csv(csv_content):
    """
    Reads CSV, adds a new column 'Processed' = 'Yes' for each row.
    """
    input_stream = io.StringIO(csv_content)
    reader = csv.reader(input_stream)
    output_stream = io.StringIO()
    writer = csv.writer(output_stream)

    # Grab headers
    headers = next(reader)
    headers.append("Processed")
    writer.writerow(headers)

    # Append 'Yes' to each row
    for row in reader:
        row.append("Yes")
        writer.writerow(row)

    return output_stream.getvalue()
